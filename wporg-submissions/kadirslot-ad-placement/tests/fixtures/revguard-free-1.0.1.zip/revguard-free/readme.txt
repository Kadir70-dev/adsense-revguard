=== RevGuard Free ===
Contributors: abdulkadirco
Tags: ads, advertising, ad insertion, shortcodes
Requires at least: 6.0
Tested up to: 7.1.3
Requires PHP: 8.2
Stable tag: 1.0.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Manage up to three ad slots with manual shortcodes and automatic post/page placements.

== Description ==
RevGuard Free provides useful ad placement without requiring an account or external API. Add up to three slots and display them at the beginning, middle, end or after a specified paragraph, or manually with [revguard_ad id="1"]. Only administrators who have unfiltered_html permission can save custom script-bearing advertising code. RevGuard Free does not collect visitor risk signals, store visitor identifiers, or send analytics to a remote service.

== Installation ==
1. Upload ZIP via Plugins > Add New > Upload Plugin.
2. Activate RevGuard Free.
3. Go to Settings > RevGuard Free.
4. Configure and enable an ad slot.
5. Use automatic placement or [revguard_ad id="1"].

== Frequently Asked Questions ==
= Does this protect Google AdSense accounts? =
No. This edition is ad placement only and makes no guarantee about invalid traffic or advertising revenue.

= What happens on uninstall? =
Saved slot settings remain unless manually deleted. Deactivation also preserves configuration.

= Can Free and Pro run at the same time? =
They use distinct options and shortcode names, but running overlapping automatic placements can create duplicate ads. Configure only one plugin to auto-place ads on a given page.

== Changelog ==
= 1.0.1 =
* RevGuard Pro compatibility: Free stops rendering ads while Pro is active and keeps its saved settings for downgrade.

= 1.0.0 =
* First free edition: three slots, automatic insertion, shortcode, secure admin form.
