<?php
/**
 * Plugin Name: RevGuard Free
 * Description: Lightweight WordPress ad placement with three ad slots, automatic placements and shortcodes.
 * Version: 1.0.1
 * Requires at least: 6.0
 * Requires PHP: 8.2
 * Author: Abdul Kadir
 * License: GPL-2.0-or-later
 * Text Domain: revguard-free
 */
declare(strict_types=1);
namespace RevGuardFree;
if (!defined('ABSPATH')) { exit; }
const VERSION = '1.0.1';
const OPTION = 'revguard_free_slots';
const MAX_SLOTS = 3;
/** The Pro plugin owns rendering while active. Free settings are retained for downgrade. */
function pro_active(): bool {
    return defined('REVGUARD_PRO_VERSION') && class_exists('\RevGuardPro\Plugin', false);
}
function defaults(): array {
    $slots=[];
    for ($i=1;$i<=MAX_SLOTS;$i++) $slots[$i]=['enabled'=>false,'code'=>'','position'=>'manual','paragraph'=>2];
    return $slots;
}
function normalized($data): array {
    $result=defaults();
    if (!is_array($data)) return $result;
    foreach ($result as $id=>$item) {
        $slot=$data[$id]??$data[(string)$id]??null;
        if (!is_array($slot)) continue;
        $pos=$slot['position']??'manual';
        $result[$id]=[
            'enabled'=>in_array($slot['enabled']??false,[true,1,'1','on'],true),
            'code'=>is_string($slot['code']??null)?substr($slot['code'],0,20000):'',
            'position'=>is_string($pos)&&in_array($pos,['manual','beginning','middle','end','after_paragraph'],true)?$pos:'manual',
            'paragraph'=>max(1,min(100,(int)($slot['paragraph']??2))),
        ];
    }
    return $result;
}
function slots(): array {return normalized(get_option(OPTION,[]));}
function ad(int $id): string {
    if (pro_active() || $id<1||$id>MAX_SLOTS) return '';
    $slot=slots()[$id];
    if (!$slot['enabled']||trim($slot['code'])==='') return '';
    // Only users with unfiltered_html may save scripts; script-containing ad code is intentionally rendered unescaped.
    return '<div class="revguard-free-ad" data-revguard-free-slot="'.esc_attr((string)$id).'">'.$slot['code'].'</div>';
}
function inject(string $content): string {
    if (pro_active()) return $content;
    if (is_admin()||is_feed()||(!is_singular('post')&&!is_singular('page'))||!in_the_loop()||!is_main_query()) return $content;
    $ends=[];
    if(preg_match_all('~</p\s*>~i',$content,$matches,PREG_OFFSET_CAPTURE))foreach($matches[0] as $m)$ends[]=$m[1]+strlen($m[0]);
    $edits=[];
    foreach(slots() as $id=>$slot){
        if(!$slot['enabled']||$slot['position']==='manual')continue;
        $html=ad((int)$id);if($html==='')continue;
        $n=count($ends);
        $at=match($slot['position']){
            'beginning'=>0,
            'middle'=>$n?$ends[(int)floor(($n-1)/2)]:strlen($content),
            'after_paragraph'=>$n&&$slot['paragraph']<=$n?$ends[$slot['paragraph']-1]:strlen($content),
            default=>strlen($content)
        };
        $edits[]=['at'=>$at,'id'=>$id,'html'=>$html];
    }
    usort($edits,static fn($a,$b)=>($b['at']<=>$a['at'])?:($b['id']<=>$a['id']));
    foreach($edits as $edit)$content=substr_replace($content,$edit['html'],$edit['at'],0);
    return $content;
}
function save(): void {
    if(($_SERVER['REQUEST_METHOD']??'')!=='POST')wp_die('Method not allowed','',['response'=>405]);
    if(!current_user_can('manage_options'))wp_die('Not allowed','',['response'=>403]);
    check_admin_referer('revguard_free_save');
    $raw=isset($_POST['slots'])&&is_array($_POST['slots'])?wp_unslash($_POST['slots']):[];
    if(strlen(wp_json_encode($raw))>75000)wp_die('Ad configuration too large','',['response'=>413]);
    $clean=[];$prior=slots();
    for($i=1;$i<=MAX_SLOTS;$i++){
        $entry=$raw[$i]??[];if(!is_array($entry))$entry=[];
        $clean[$i]=[
            'enabled'=>isset($entry['enabled'])?'1':'0',
            'position'=>is_string($entry['position']??null)?sanitize_key($entry['position']):'manual',
            'paragraph'=>absint($entry['paragraph']??2),
            'code'=>current_user_can('unfiltered_html')&&is_string($entry['code']??null)?substr($entry['code'],0,20000):($prior[$i]['code']??''),
        ];
    }
    update_option(OPTION,normalized($clean),false);
    wp_safe_redirect(admin_url('options-general.php?page=revguard-free&saved=1'));
    exit;
}
function screen(): void {
    if(!current_user_can('manage_options'))wp_die('Not allowed','',['response'=>403]);
    $slots=slots();
    echo '<div class="wrap rgf-admin"><h1>RevGuard Free — Ad Slots</h1><p>Manage up to 3 ad slots on posts and pages. Use <code>[revguard_ad id="1"]</code> for manual placement.</p>';
    echo '<p>Only administrators with <code>unfiltered_html</code> can save custom advertising scripts. Check your ad network policies before publishing ads.</p>';
    if(isset($_GET['saved']))echo '<div class="notice notice-success"><p>Ad slots saved.</p></div>';
    if(pro_active())echo '<div class="notice notice-info"><p>RevGuard Pro is active and handles all ad rendering. RevGuard Free settings remain saved and are restored automatically if Pro is deactivated. Manage active ad slots in RevGuard Pro.</p></div>';
    echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="revguard_free_save">';
    wp_nonce_field('revguard_free_save');
    foreach($slots as $id=>$slot){
        echo '<section class="rgf-card"><h2>Ad slot '.esc_html((string)$id).'</h2>';
        echo '<label><input type="checkbox" name="slots['.$id.'][enabled]" value="1" '.checked($slot['enabled'],true,false).'> Enabled</label> ';
        echo '<label> Placement <select name="slots['.$id.'][position]">';
        foreach(['manual','beginning','middle','end','after_paragraph'] as $pos)echo '<option value="'.esc_attr($pos).'" '.selected($slot['position'],$pos,false).'>'.esc_html(ucwords(str_replace('_',' ',$pos))).'</option>';
        echo '</select></label> <label>Paragraph <input type="number" min="1" max="100" name="slots['.$id.'][paragraph]" value="'.esc_attr((string)$slot['paragraph']).'" style="width:75px"></label>';
        echo '<p><label for="rgf-code-'.$id.'">Ad HTML / JavaScript</label></p><textarea id="rgf-code-'.$id.'" name="slots['.$id.'][code]" rows="5" class="large-text code" '.(!current_user_can('unfiltered_html')?'readonly':'').'>'.esc_textarea($slot['code']).'</textarea></section>';
    }
    submit_button('Save ad slots');echo '</form><p><strong>RevGuard Pro:</strong> advanced visitor risk signals, ad protection controls, analytics and whitelisting are available separately. Free does not track visitor behavior.</p></div>';
}
function boot():void {
    add_filter('the_content',__NAMESPACE__.'\\inject',20);
    add_shortcode('revguard_ad',static function($attrs):string{$vals=shortcode_atts(['id'=>1],is_array($attrs)?$attrs:[],'revguard_ad');return ad((int)$vals['id']);});
    add_action('admin_menu',static function():void{add_options_page('RevGuard Free','RevGuard Free','manage_options','revguard-free',__NAMESPACE__.'\\screen');});
    add_action('admin_post_revguard_free_save',__NAMESPACE__.'\\save');
    add_action('admin_enqueue_scripts',static function(string $hook):void{
        if($hook==='settings_page_revguard-free')wp_enqueue_style('revguard-free-admin',plugins_url('assets/admin.css',__FILE__),[],VERSION);
    });
}
add_action('plugins_loaded',__NAMESPACE__.'\\boot');
register_activation_hook(__FILE__,static function():void{add_option(OPTION,defaults(),'',false);});
